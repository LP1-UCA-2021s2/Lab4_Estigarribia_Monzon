/*
 ============================================================================
 Name        : 2021s1_lab4.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in GTK+
 ============================================================================
 */

 #include <gtk/gtk.h>

 int main (int argc, char *argv[])
 {
	 GtkWidget *window;
	 GtkBuilder *builder;
	 GError *error = NULL;

	 gtk_init (&argc, &argv);

	 builder = gtk_builder_new();
	 //Se carga el builder
	 if (gtk_builder_add_from_file(builder, "juego.glade", &error) == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
		return 1;
	 }

	 //Ventana principal
	 window = GTK_WIDGET(gtk_builder_get_object(builder, "my_window"));
	 g_signal_connect (window, "destroy", gtk_main_quit, NULL);

	 gtk_widget_show_all (window);
	 gtk_main();

	 return 0;
 }
